<?php
    if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
        /* 
           Up to you which header to send, some prefer 404 even if 
           the files does exist for security
        */
        header( 'HTTP/1.0 404 Forbidden', TRUE, 404 );

        /* choose the appropriate page to redirect users */
        die( header( 'location: /error.php' ) );

    }
?>
<?php
include '../backend/db/db_conn.inc.php';
include_once '../backend/function.inc.php';

// Get the form data
$email = mysqli_real_escape_string($conn, $_POST["email"]);
$password = mysqli_real_escape_string($conn, md5($_POST["password"]));

// Prepare and execute the SQL query
$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE email = ?");
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

// Check if the email exists in the database
if (mysqli_num_rows($result) == 1) {
  // Fetch the user's data from the database
  $row = mysqli_fetch_assoc($result);
  
  // Check if the password matches
  if ($password == $row["password"]) {
    // Start a session and set the user ID
    session_start();
    $_SESSION["user_id"] = $row["id"];

    // Return a JSON response with a success message
    $response = array(
      "success" => true,
      "message" => "Login successful!"
    );
    echo json_encode($response);
  } else {
    // Return a JSON response with an error message
    $response = array(
      "success" => false,
      "message" => "Invalid password!"
    );
    echo json_encode($response);
  }
} else {
  // Return a JSON response with an error message
  $response = array(
    "success" => false,
    "message" => "Email not found!"
  );
  echo json_encode($response);
}

// Close the database connection
mysqli_stmt_close($stmt);
mysqli_close($conn);