<?php
    if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
        /* 
           Up to you which header to send, some prefer 404 even if 
           the files does exist for security
        */
        header( 'HTTP/1.0 404 Forbidden', TRUE, 404 );

        /* choose the appropriate page to redirect users */
        die( header( 'location: /error.php' ) );

    }
?>
<?php
include '../backend/db/db_conn.inc.php';
include_once '../backend/function.inc.php';

// Process the form data
$firstName = mysqli_real_escape_string($conn, $_POST["first-name"]);
$lastName = mysqli_real_escape_string($conn, $_POST["last-name"]);
$email = mysqli_real_escape_string($conn, $_POST["email"]);
$password = mysqli_real_escape_string($conn, md5($_POST["password"]));
$retypePassword = mysqli_real_escape_string($conn, md5($_POST["retype-password"]));

// Validate the email address
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  // Invalid email address
  $response ="Invalid email address";
  echo $response;
}

// Validate the password
if (!preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,}$/', $password)) {
  // Invalid password
  $response = "Invalid password. Password must be at least 8 characters long and contain at least one letter, one number, and one special character (!@#$%)";
  echo $response;
}

// Validate the retyped password
if ($password !== $retypePassword) {
  // Passwords don't match
  $response = "Passwords don't match";
  echo $response;
}

// Generate a unique code
$code = generate_code();

// Store the user data and code in the database
$sql = "INSERT INTO users (first_name, last_name, email, password, code) VALUES ('$firstName', '$lastName', '$email', '$password', '$code')";
if (mysqli_query($conn, $sql)) {
  // Registration successful
  $response = "Registration successful! Your unique code is: " . '<strong>'. $code . '</strong>';
  echo $response;
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
