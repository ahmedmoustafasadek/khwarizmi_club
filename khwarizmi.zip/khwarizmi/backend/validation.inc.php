<?php
    if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
        /* 
           Up to you which header to send, some prefer 404 even if 
           the files does exist for security
        */
        header( 'HTTP/1.0 404 Forbidden', TRUE, 404 );

        /* choose the appropriate page to redirect users */
        die( header( 'location: /error.php' ) );

    }
?>
<?php
include '../backend/db/db_conn.inc.php';
include_once '../backend/function.inc.php';

// Check if the code was submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	// Sanitize and store the user's code
	$code = mysqli_real_escape_string($conn, $_POST["code"]);

	// Query the users and users_data tables for the user's information
	$sql = "SELECT users.*, users_data.branch, users_data.committee FROM users INNER JOIN users_data ON users.id = users_data.user_id WHERE users.code = '$code'";
	$result = mysqli_query($conn, $sql);

	// Check if the query returned any results
	if (mysqli_num_rows($result) > 0) {
		
		// Display the user's information
		$row = mysqli_fetch_assoc($result);
		echo "<h2>Your Information:</h2>";
		echo "Name: " . $row["first_name"] . " " . $row["last_name"] . "<br>"."<br>";
		echo "Email: " . $row["email"] . "<br>"."<br>";
		echo "Branch: " . $row["branch"] . "<br>"."<br>";
		echo "Committee: " . $row["committee"] . "<br>"."<br>";
        echo "Email: " . $row["reg_date"] . "<br>"."<br>";

	} else {
		// Display an error message if no results were found
		echo "Invalid code. Please try again.";
	}

	// Close the database connection
	mysqli_close($conn);
}