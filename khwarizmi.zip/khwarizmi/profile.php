<?php
// Start the session
session_start();

// Check if the user is already logged in
if (!isset($_SESSION["user_id"])) {
    // Redirect to the login page
    header("Location: login.html");
    exit;
}
// If the user is logged in and clicks on the logout link
if (isset($_GET["logout"]) && $_GET["logout"] == "true") {
    // Unset all session variables
    $_SESSION = array();

    // Destroy the session
    session_destroy();

    // Redirect to the login page
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./vendor/css/style.css">
    <title>profile</title>
</head>
<body>
    <!-- HTML code for the logout link -->
    <a href="?logout=true">Logout</a>
</form>
</body>
</html>