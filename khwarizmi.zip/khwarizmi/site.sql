-- Create a table named "users"
CREATE TABLE users (
  id INT(6) AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(30) NOT NULL,
  last_name VARCHAR(30) NOT NULL,
  email VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,
  code VARCHAR(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create a table named "users_data"
CREATE TABLE users_data (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  branch VARCHAR(255) NOT NULL,
  committee VARCHAR(255) NOT NULL,
  user_id INT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);